# Multi-Factor Fundamental Screener & Dashboard

A cross-sectional equity screener that ranks a stock universe on **Value**,
**Quality**, and **Growth** factors using sector-neutral z-scoring, built to
run end-to-end in Google Colab and produce an interactive research dashboard.

## What it does

Pulls fundamentals + prices for the S&P 500, engineers a set of valuation,
quality, and growth ratios, sector-neutralizes them (so a bank's P/E isn't
compared directly to a software company's), blends them into a single
composite score, and outputs:

- A ranked CSV of the full universe
- A markdown research summary (top 20 names + validation stats)
- Static charts (sector heatmap, top/bottom bar chart, factor correlation matrix)
- An interactive 4-panel Plotly dashboard

## Quickstart (Google Colab)

1. Open a new Colab notebook.
2. Copy each `# CELL N` block from [`multi_factor_screener.py`](./multi_factor_screener.py)
   into its own cell, in order (cell boundaries are marked with `# %%`).
3. Run Cell 1 to install dependencies.
4. Adjust `CONFIG` in Cell 2 — set `max_tickers=None` for a full S&P 500 run
   (slower), or leave capped at 100 for a quick demo.
5. Run the remaining cells in order. The final cell calls `run_pipeline()`
   and displays the interactive dashboard.

## Quickstart (local / script)

```bash
pip install -r requirements.txt
python multi_factor_screener.py
```

## Configuration

All tunable parameters live in the `Config` dataclass near the top of the
script — universe size, minimum market cap, API rate-limit delay, retry
behavior, winsorization limits, and an optional Financial Modeling Prep
API key for supplementary ratio data (`fmp_api_key`; the pipeline runs fine
without one, using yfinance as the sole free data source).

## Methodology notes

- **Sector neutrality:** every raw metric is z-scored *within its GICS
  sector* before being combined, so the screen compares Financials to
  Financials and Tech to Tech rather than penalizing structurally
  different business models.
- **Winsorization:** the top/bottom 2% of each raw metric is clipped before
  scoring to limit the influence of data errors and extreme outliers.
- **Signal validation is a sanity check, not a backtest.** Free fundamentals
  APIs return current snapshot data rather than point-in-time history, so
  `evaluate_signal()` measures the *concurrent* relationship between
  today's score and the trailing 12-month return. A genuine leakage-free
  backtest would require point-in-time fundamentals (e.g., via WRDS/
  Compustat) matched against **forward** returns — this limitation is
  called out explicitly in the code and the generated report.

## Data sources

| Source | Used for | API key required? |
|---|---|---|
| Yahoo Finance (`yfinance`) | Prices, market cap, core fundamentals | No |
| Wikipedia | S&P 500 constituent list | No |
| Financial Modeling Prep | Optional supplementary ROIC/FCF-yield | Yes (optional) |

## Project structure

```
multi_factor_screener/
├── README.md
├── requirements.txt
├── multi_factor_screener.py   # full pipeline, organized as Colab cells
└── outputs/                   # generated on run: CSV + report + figures
```

## Possible upgrades

- Swap the trailing-return sanity check for a true point-in-time backtest
  using a vendor with as-reported fundamentals history.
- Add sector/size-neutral factor combination weights learned via regression
  instead of equal-weighting Value/Quality/Growth.
- Extend to international indices or a custom liquid-universe filter.
- Schedule as a recurring Colab job (or GitHub Action) to track score drift
  and turnover week over week.
